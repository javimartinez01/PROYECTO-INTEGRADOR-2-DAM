package com.dam.proyectointegrador.DB;


import com.dam.proyectointegrador.Entity.Peliculas;

import java.util.ArrayList;

public class Datos {

    private ArrayList<Peliculas> peliculas;

    public Datos(){
        peliculas = new ArrayList<Peliculas>();
        cargarPeliculas();
    }

    public void cargarPeliculas() {

        peliculas.add(new Peliculas("Creed 3", "Acción", "Michael B. Jordan", "Michael B. Jordan, Tessa Thompson, Jonathan Mayors", "Adonis Creed está prosperando en su carrera y en su vida familiar. Cuando un amigo de la infancia y antiguo prodigio del boxeo reaparece tras cumplir condena en la cárcel, está ansioso por demostrar que merece su oportunidad en el ring."));

        peliculas.add(new Peliculas( "Mari(dos)", "Comedia", "Lucia Alemany", "Paco León,Ernesto Alterio, Celia Freijeiro, Raul Cimas", "Toni y Emilio reciben la misma trágica llamada: sus mujeres están en coma tras un alud en una estación de esquí. Cuando se presentan en el mostrador de admisiones del hospital hacen un sorprendente descubrimiento: sus mujeres son, en realidad, la misma persona"));

        peliculas.add(new Peliculas("Scream IV", "Terror", "Wes Craven", "Wes Craven, Neve Campbell, Courteney Cox David Arquette, Emma Roberts", "Diez años después de los asesinatos de Woodsbord, Sidney Prescott, convertida en una escritora de éxito, vuelve a su pueblo natal, pero su regreso irá acompañado de una nueva ola de crímenes perpetrados por un viejo conocido."));

        peliculas.add(new Peliculas("Ant-Man y la Avispa: Quantumanía", "Ciencia Ficción", "Peyton Reed", "Paul Rudd, Jonathan Mayors, Evangeline Lilly, Kathryn Newton, Michael Douglas, Michelle Pfeiffer", "Los superhéroes Scott y Cassie Lang, Hope van Dyne y sus padres, se encuentran accidentalmente atrapados en el reino cuántico y deben enfrentarse a un nuevo enemigo, Kang el Conquistador."));

        peliculas.add(new Peliculas( "Avatar: El sentido del agua", "Ciencia Ficción", "James Cameron", "Sam Worthington, Zoe Saldaña, Kate Winslet, Sigourney Weaver, Stephen Lang", "Jake Sully y Ney'tiri han formado una familia y hacen todo lo posible por permanecer juntos. Sin embargo, deben abandonar su hogar y explorar las regiones de Pandora cuando una antigua amenaza reaparece."));

        peliculas.add(new Peliculas ( "La ballena (The Whale)", "Drama", "Darren Aronofsky", "Brendan Frasser, Hong Chau, Saddie Sink, Ty Simpkins, Samantha Morton", "Un solitario profesor de inglés que tiene obesidad mórbida y vive recluido intenta reconectar con su hija adolescente para tener una última oportunidad de redención."));

        peliculas.add(new Peliculas("El Gato Con Botas: El último deseo", "Comedia", "Joel Crawford", "Antonio Banderas, Salma Hayek, Harvey Guillén, Wagner Moura", "El Gato con Botas descubre que su pasión por la aventura le ha pasado factura: ha consumido ocho de sus nueve vidas, por ello emprende un viaje épico para encontrar el mítico Último Deseo y restaurar sus nueve vidas."));

        peliculas.add(new Peliculas("Babylon", "Comedia", "Damien Chazelle", "Margot Robbie, Brad Pitt, Tobey Maguire, Olivia Wilde", "La decadencia, la depravación y los excesos escandalosos provocan el ascenso y la caída de varios ambiciosos soñadores en el Hollywood de los años veinte."));

        peliculas.add(new Peliculas("Momias", "Comedia", "Juan Jesús García Galocha", "Sean Bean, Eleanor Tomilnson, Joe Thomas, Hugh Bonnevillle", "En las entrañas de la tierra, existe una ciudad de momias. Por mandato imperial, la Princesa Nefer debe casarse con Thut, un exauriga de carros. Ninguno desea el matrimonio, pero los designios de los dioses son irrevocables."));

        peliculas.add(new Peliculas("Missing", "Drama", "Nicholas D. Jhonson, Will Merrick", "Storm Reid, Nia Long, Megan Suri, Ken Leung, Thomas Barbusa", "Cuando su madre (Nia Long) desaparece mientras está de vacaciones en Colombia con su nuevo novio, la búsqueda de respuestas de June (Storm Reid) se ve obstaculizada por la burocracia internacional. Atrapada a miles de kilómetros de distancia en Los Ángeles, June utiliza creativamente toda la última tecnología a su alcance para tratar de encontrarla antes de que sea demasiado tarde."));

    }

    public ArrayList<Peliculas> getListaPelis(){
        return peliculas;
    }

}
