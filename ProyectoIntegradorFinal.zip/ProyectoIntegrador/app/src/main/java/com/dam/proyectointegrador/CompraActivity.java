package com.dam.proyectointegrador;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.dam.proyectointegrador.seleccion.SeleccionCineActivity;
import com.dam.proyectointegrador.seleccion.SeleccionPeliculaActivity;

public class CompraActivity extends AppCompatActivity {

    EditText etPelicula;
    EditText etFechaHora;
    EditText etFila;
    EditText etNumeroTickets;
    EditText etCine;
    Button btnSeleccionarPelicula;
    Button btnSeleccionarCine;
    Button btnComprar;
    Button btnCancelar;

    String Pelicula;
    String Cine;

    public static boolean PELICULA = false;
    public static boolean CINE = false;

    ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    System.out.println(result.getResultCode());
                    if (result.getResultCode() == SeleccionPeliculaActivity.PELICULA) {
                        Pelicula = result.getData().getStringExtra(SeleccionPeliculaActivity.S_PELICULA);
                        etPelicula.setText(Pelicula);
                        PELICULA = false;
                    }
                    if (result.getResultCode() == SeleccionCineActivity.CINES) {
                        Cine = result.getData().getStringExtra(SeleccionCineActivity.S_CINE);
                        etCine.setText(Cine);
                        CINE = false;
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compra);

        etPelicula = findViewById(R.id.etPelicula);
        etFechaHora = findViewById(R.id.etFechaHora);
        etFila = findViewById(R.id.etFila);
        etNumeroTickets = findViewById(R.id.etNumeroTickets);
        etCine = findViewById(R.id.etCine);

        btnSeleccionarPelicula = findViewById(R.id.btnSeleccionarPelicula);
        btnSeleccionarCine = findViewById(R.id.btnSeleccionarCine);
        btnComprar = findViewById(R.id.btnComprar);
        btnCancelar = findViewById(R.id.btnCancelar);

        etPelicula.setEnabled(false);
        etCine.setEnabled(false);


        btnSeleccionarPelicula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent ip = new Intent(CompraActivity.this, SeleccionPeliculaActivity.class);
                PELICULA = true;
                resultLauncher.launch(ip);

            }
        });


        Pelicula = getIntent().getStringExtra(SeleccionPeliculaActivity.S_PELICULA);
        etPelicula.setText(Pelicula);

        btnSeleccionarCine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ic = new Intent(CompraActivity.this, SeleccionCineActivity.class);
                CINE = true;
                resultLauncher.launch(ic);
            }
        });

        Cine = getIntent().getStringExtra(SeleccionCineActivity.S_CINE);
        etCine.setText(Cine);

        btnComprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (etPelicula.getText().toString().isEmpty() ||
                        etFechaHora.getText().toString().isEmpty() ||
                        etFila.getText().toString().isEmpty() ||
                        etNumeroTickets.getText().toString().isEmpty() ||
                        etCine.getText().toString().isEmpty()) {
                    Toast.makeText(CompraActivity.this, "Debe introducir todos los datos", Toast.LENGTH_SHORT).show();
                } else {
                    String pelicula = etPelicula.getText().toString();
                    String fechahora = etFechaHora.getText().toString();
                    int fila = Integer.parseInt(etFila.getText().toString());
                    int numerotickets = Integer.parseInt(etNumeroTickets.getText().toString());
                    String cine = etCine.getText().toString();

                    Intent entradaIntent = new Intent(CompraActivity.this, EntradaActivity.class);
                    entradaIntent.putExtra("pelicula", pelicula);
                    entradaIntent.putExtra("fechahora", fechahora);
                    entradaIntent.putExtra("fila", fila);
                    entradaIntent.putExtra("numerotickets", numerotickets);
                    entradaIntent.putExtra("cine", cine);
                    startActivity(entradaIntent);
                }
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                etPelicula.getText().clear();
                etFechaHora.getText().clear();
                etFila.getText().clear();
                etNumeroTickets.getText().clear();
                etCine.getText().clear();

                finish();
            }
        });


    }




}