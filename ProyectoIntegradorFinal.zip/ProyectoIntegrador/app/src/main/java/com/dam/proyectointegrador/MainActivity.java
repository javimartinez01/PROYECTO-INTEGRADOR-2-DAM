package com.dam.proyectointegrador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText  etUsuario;
    EditText etContrasena;
    Button btnComprarEntrada;
    Button btnQuejaFormal;
    Button btnConsultar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuario = findViewById(R.id.etUsuario);
        etContrasena = findViewById(R.id.etContrasena);
        btnComprarEntrada = findViewById(R.id.btnComprarEntrada);
        btnQuejaFormal = findViewById(R.id.btnQuejaFormal);
        btnConsultar = findViewById(R.id.btnConsultar);

        btnComprarEntrada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etUsuario.getText().toString().isEmpty() ||
                        etContrasena.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Debes introducir un Usuario y su Contraseña", Toast.LENGTH_SHORT).show();
                } else if (etUsuario.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Debes introducir un Usuario", Toast.LENGTH_SHORT).show();
                } else if (etContrasena.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Debes introducir una Contraseña", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(MainActivity.this, CompraActivity.class);
                    startActivity(intent);
                }
            }
        });

        btnQuejaFormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, QuejaActivity.class);
                startActivity(intent);
            }
        });

        btnConsultar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (etUsuario.getText().toString().isEmpty() ||
                        etContrasena.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Debes introducir un Usuario y su Contraseña", Toast.LENGTH_SHORT).show();
                } else if (etUsuario.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Debes introducir un Usuario", Toast.LENGTH_SHORT).show();
                } else if (etContrasena.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Debes introducir una Contraseña", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(MainActivity.this, CinesPeliculasActivity.class);
                    startActivity(intent);
                }
            }
        });

    }
}