package com.dam.proyectointegrador.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dam.proyectointegrador.DB.Datos;
import com.dam.proyectointegrador.Entity.Peliculas;
import com.dam.proyectointegrador.R;

import java.util.ArrayList;


public class CarteleraFragment extends Fragment {

    String titulo2;
    String genero2;
    String director2;
    String reparto2;
    String sinopsis2;

    TextView tituloTextView;
    TextView generoTextView;
    TextView directorTextView;
    TextView repartoTextView;
    TextView sinopsisTextView;

    Datos data = new Datos();
    ArrayList<Peliculas> peliculas;

    public CarteleraFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_cartelera,
            container, false);

        tituloTextView = view.findViewById(R.id.tituloTextView);
        tituloTextView.setText(titulo2);

        generoTextView = view.findViewById(R.id.generoTextView);
        generoTextView.setText(genero2);

        directorTextView = view.findViewById(R.id.directorTextView);
        directorTextView.setText(director2);

        repartoTextView = view.findViewById(R.id.repartoTextView);
        repartoTextView.setText(reparto2);

        sinopsisTextView = view.findViewById(R.id.sinopsisTextView);
        sinopsisTextView.setText(sinopsis2);

        return view;
    }
}