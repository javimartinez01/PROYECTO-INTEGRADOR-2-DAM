package com.dam.proyectointegrador.seleccion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.dam.proyectointegrador.CompraActivity;
import com.dam.proyectointegrador.R;

public class SeleccionPeliculaActivity extends AppCompatActivity {

    Button btnCreed3;
    Button btnMaridos;
    Button btnScreamIV;
    Button btnAntmanyAvispa;
    Button btnAvatar;
    Button btnLaBallena;
    Button btnElGatoConBotas;
    Button btnBabylon;
    Button btnMomias;
    Button btnMissing;

    Button btnPeliculaSeleccionada;
    Button btnCancelarPeliculaSeleccion;
    EditText etPeliculaSeleccionada;

    String Pelicula;
    public static final int PELICULA = 101;
    public static final String S_PELICULA = "Pelicula";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion_pelicula);

        btnPeliculaSeleccionada = findViewById(R.id.btnPeliculaSeleccionada);
        btnCancelarPeliculaSeleccion = findViewById(R.id.btnCancelarPeliculaSeleccion);
        etPeliculaSeleccionada = findViewById(R.id.etPeliculaSeleccionada);

        btnCreed3 = findViewById(R.id.btnCreed3);
        btnMaridos = findViewById(R.id.btnMaridos);
        btnScreamIV = findViewById(R.id.btnScreamIV);
        btnAntmanyAvispa = findViewById(R.id.btnAntmanyAvispa);
        btnAvatar = findViewById(R.id.btnAvatar);
        btnLaBallena = findViewById(R.id.btnLaBallena);
        btnElGatoConBotas = findViewById(R.id.btnElGatoConBotas);
        btnBabylon = findViewById(R.id.btnBabylon);
        btnMomias = findViewById(R.id.btnMomias);
        btnMissing = findViewById(R.id.btnMissing);

        etPeliculaSeleccionada.setEnabled(false);

        btnCreed3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_creed3)));
            }
        });

        btnMaridos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_mariDos)));
            }
        });

        btnScreamIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_screamIV)));
            }
        });

        btnAntmanyAvispa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_antman_y_avispa)));
            }
        });

        btnAvatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_avatar)));
            }
        });

        btnLaBallena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_la_ballena)));
            }
        });

        btnElGatoConBotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_el_gato_con_botas)));
            }
        });

        btnBabylon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_babylon)));
            }
        });

        btnMomias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_momias)));
            }
        });

        btnMissing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etPeliculaSeleccionada.setText(String.format(getResources().getString(R.string.btn_missing)));
            }
        });

        btnPeliculaSeleccionada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etPeliculaSeleccionada.getText().toString().isEmpty()){
                    Toast.makeText(SeleccionPeliculaActivity.this, "Debe seleccionar una Pelicula", Toast.LENGTH_SHORT).show();
                } else {
                    Pelicula = etPeliculaSeleccionada.getText().toString();
                    System.out.println(Pelicula);
                    if(CompraActivity.PELICULA){
                        setResult(PELICULA, new Intent().putExtra(S_PELICULA, Pelicula));
                        CompraActivity.PELICULA = false;
                    }

                    finish();
                }

            }
        });

        btnCancelarPeliculaSeleccion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED, new Intent());
                finish();
            }
        });

    }
}