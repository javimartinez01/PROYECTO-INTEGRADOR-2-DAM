package com.dam.proyectointegrador.util;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.dam.proyectointegrador.Entity.Peliculas;
import com.dam.proyectointegrador.R;

import java.util.ArrayList;

public class PeliculasAdapter extends RecyclerView.Adapter<PeliculasAdapter.PeliculaVH>
implements View.OnClickListener {

    private ArrayList<Peliculas> datos;
    private View.OnClickListener listener;


    public PeliculasAdapter(ArrayList<Peliculas> datos) {
        this.datos = datos;
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View v) {
        if (listener != null) {
            listener.onClick(v);
        }
    }

    @NonNull
    @Override
    public PeliculaVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_cartelera, parent, false);
        v.setOnClickListener(this);

        PeliculaVH vh = new PeliculaVH(v);
        return vh;

    }

    @Override
    public void onBindViewHolder(@NonNull PeliculaVH holder, int position) {
        holder.bindPeliculas(datos.get(position));
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public class PeliculaVH extends RecyclerView.ViewHolder {
        private TextView tvTit;
        private TextView tvGen;
        private TextView tvDir;
        private TextView tvRep;
        private TextView tvSinop;


        public PeliculaVH(@NonNull View itemView) {
            super(itemView);
            tvTit = itemView.findViewById(R.id.tituloTextView);
            tvGen = itemView.findViewById(R.id.generoTextView);
            tvDir = itemView.findViewById(R.id.directorTextView);
            tvRep = itemView.findViewById(R.id.repartoTextView);
            tvSinop = itemView.findViewById(R.id.sinopsisTextView);
        }

        public void bindPeliculas(Peliculas peliculas) {
            tvTit.setText(peliculas.getTitulo());
            tvGen.setText(peliculas.getGenero());
            tvDir.setText(peliculas.getDirector());
            tvRep.setText(peliculas.getReparto());
            tvSinop.setText(peliculas.getSinopsis());
        }
    }
}
