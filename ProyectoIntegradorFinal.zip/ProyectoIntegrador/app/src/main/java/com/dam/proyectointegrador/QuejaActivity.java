package com.dam.proyectointegrador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class QuejaActivity extends AppCompatActivity {

    EditText etNombre;
    EditText etApellidos;
    EditText etCodigoPostal;
    EditText etDNI;
    EditText etQueja;
    Button btnAceptar;
    Button btnCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_queja);

        etNombre = findViewById(R.id.etNombre);
        etApellidos = findViewById(R.id.etApellidos);
        etCodigoPostal = findViewById(R.id.etCodigoPostal);
        etDNI = findViewById(R.id.etDNI);
        etQueja = findViewById(R.id.etQueja);
        btnAceptar = findViewById(R.id.btnAceptar);
        btnCancelar = findViewById(R.id.btnCancelar);

        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etNombre.getText().toString().isEmpty() ||
                        etApellidos.getText().toString().isEmpty() ||
                        etCodigoPostal.getText().toString().isEmpty() ||
                        etDNI.getText().toString().isEmpty() ||
                        etQueja.getText().toString().isEmpty())
                {
                    Toast.makeText(QuejaActivity.this, "Debe introducir todos sus datos y el motivo de la queja", Toast.LENGTH_SHORT).show();
                } else if (etQueja.getText().toString().isEmpty()){
                    Toast.makeText(QuejaActivity.this, "Debe introducir el motivo de la queja", Toast.LENGTH_SHORT).show();
                } else if (etNombre.getText().toString().isEmpty() ||
                        etApellidos.getText().toString().isEmpty() ||
                        etCodigoPostal.getText().toString().isEmpty() ||
                        etDNI.getText().toString().isEmpty()){
                    Toast.makeText(QuejaActivity.this, "Debe introducir todos sus datos", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(QuejaActivity.this, "Hemos recibido tu queja. Trataremos de solucionar el problema cuanto antes.", Toast.LENGTH_SHORT).show();
                    etNombre.getText().clear();
                    etApellidos.getText().clear();
                    etCodigoPostal.getText().clear();
                    etDNI.getText().clear();
                    etQueja.getText().clear();

                    finish();
                }
            }
        });

        btnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }
}