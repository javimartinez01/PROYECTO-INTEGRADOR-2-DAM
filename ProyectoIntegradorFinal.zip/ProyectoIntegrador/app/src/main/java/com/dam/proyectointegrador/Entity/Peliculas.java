package com.dam.proyectointegrador.Entity;


import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import com.dam.proyectointegrador.R;

@Entity (tableName = "PELICULAS")

public class Peliculas {

    @NonNull
    @ColumnInfo (name = "titulo")
    public String titulo;

    @NonNull
    @ColumnInfo (name = "genero")
    public String genero;

    @NonNull
    @ColumnInfo (name = "director")
    public String director;

    @NonNull
    @ColumnInfo (name = "reparto")
    public String reparto;

    @NonNull
    @ColumnInfo (name = "sinopsis")
    public String sinopsis;

    public Peliculas(String titulo,
                     String genero,
                     String director,
                     String reparto,
                     String sinopsis) {
        this.titulo = titulo;
        this.genero = genero;
        this.director = director;
        this.reparto = reparto;
        this.sinopsis = sinopsis;
    }

    @NonNull
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(@NonNull String titulo) {
        this.titulo = titulo;
    }

    @NonNull
    public String getGenero() {
        return genero;
    }

    public void setGenero(@NonNull String genero) {
        this.genero = genero;
    }

    @NonNull
    public String getDirector() {
        return director;
    }

    public void setDirector(@NonNull String director) {
        this.director = director;
    }

    @NonNull
    public String getReparto() {
        return reparto;
    }

    public void setReparto(@NonNull String reparto) {
        this.reparto = reparto;
    }

    @NonNull
    public String getSinopsis() {
        return sinopsis;
    }

    public void setSinopsis(@NonNull String sinopsis) {
        this.sinopsis = sinopsis;
    }

}
