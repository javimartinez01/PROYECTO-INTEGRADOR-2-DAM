package com.dam.proyectointegrador.seleccion;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.dam.proyectointegrador.CompraActivity;
import com.dam.proyectointegrador.R;

public class SeleccionCineActivity extends AppCompatActivity {

    Button btnCineYelmoPlazaNorte;
    Button btnOdeonMulticines;
    Button btnCineYelmoPlenilunio;
    Button btnKinepolisDiversia;
    Button btnVaguadaCines;

    Button btnCineSeleccionado;
    Button btnCancelarCineSeleccion;
    EditText etCineSeleccionado;

    String Cine;
    public static final int CINES = 102;
    public static final String S_CINE = "Cine";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccion_cine);

        btnCineSeleccionado = findViewById(R.id.btnCineSeleccionado);
        btnCancelarCineSeleccion = findViewById(R.id.btnCancelarCineSeleccion);
        etCineSeleccionado = findViewById(R.id.etCineSeleccionado);

        btnCineYelmoPlazaNorte = findViewById(R.id.btnCineYelmoPlazaNorte);
        btnOdeonMulticines = findViewById(R.id.btnOdeonMulticines);
        btnCineYelmoPlenilunio = findViewById(R.id.btnCineYelmoPlenilunio);
        btnKinepolisDiversia = findViewById(R.id.btnKinepolisDiversia);
        btnVaguadaCines = findViewById(R.id.btnVaguadaCines);

        etCineSeleccionado.setEnabled(false);

        btnCineYelmoPlazaNorte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etCineSeleccionado.setText(String.format(getResources().getString(R.string.btn_cine_yelmo_plaza_norte)));
            }
        });

        btnOdeonMulticines.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etCineSeleccionado.setText(String.format(getResources().getString(R.string.btn_odeon_multicines)));
            }
        });

        btnCineYelmoPlenilunio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etCineSeleccionado.setText(String.format(getResources().getString(R.string.btn_cine_yelmo_plenilunio)));
            }
        });

        btnKinepolisDiversia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etCineSeleccionado.setText(String.format(getResources().getString(R.string.btn_kinepolis_diversia)));
            }
        });

        btnVaguadaCines.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etCineSeleccionado.setText(String.format(getResources().getString(R.string.btn_vaguada_cines)));
            }
        });

        btnCineSeleccionado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etCineSeleccionado.getText().toString().isEmpty()){
                    Toast.makeText(SeleccionCineActivity.this, "Debe seleccionar un cine", Toast.LENGTH_SHORT).show();
                } else {
                    Cine =etCineSeleccionado.getText().toString();
                    System.out.println(Cine);
                    if(CompraActivity.CINE){
                        setResult(CINES, new Intent().putExtra(S_CINE, Cine));
                        CompraActivity.CINE = false;
                    }

                    finish();
                }

            }
        });

        btnCancelarCineSeleccion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(RESULT_CANCELED, new Intent());
                finish();
            }
        });

    }
}