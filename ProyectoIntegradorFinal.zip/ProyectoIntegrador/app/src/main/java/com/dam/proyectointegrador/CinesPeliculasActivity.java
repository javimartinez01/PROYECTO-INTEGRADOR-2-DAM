package com.dam.proyectointegrador;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.dam.proyectointegrador.DB.Datos;
import com.dam.proyectointegrador.fragments.CarteleraFragment;
import com.dam.proyectointegrador.util.PeliculasAdapter;
import com.google.android.material.snackbar.Snackbar;

public class CinesPeliculasActivity extends AppCompatActivity {

    RecyclerView rv;
    PeliculasAdapter adaptador;
    RecyclerView.LayoutManager lm;
    Datos datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cines_peliculas);

        rv = findViewById(R.id.rvDatos);

        datos = new Datos();

        adaptador = new PeliculasAdapter(datos.getListaPelis());

        adaptador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int pos = rv.getChildAdapterPosition(v);
                String seleccion = "Se ha seleccionado el elemento"
                        + datos.getListaPelis().get(pos).toString();
                Snackbar.make(rv, seleccion, Snackbar.LENGTH_LONG).show();
            }
        });

        lm = new LinearLayoutManager(this);

        rv.setLayoutManager(lm);
        rv.setHasFixedSize(true);
        rv.setAdapter(adaptador);

        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.menuSalir){
            Intent intent = new Intent(CinesPeliculasActivity.this, MainActivity.class);
            startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }

    private void cargarFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .addToBackStack(null)
                .commit();
    }



}