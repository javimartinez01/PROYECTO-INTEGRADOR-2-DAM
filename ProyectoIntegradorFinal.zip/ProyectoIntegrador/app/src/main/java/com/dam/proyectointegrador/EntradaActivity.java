package com.dam.proyectointegrador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class EntradaActivity extends AppCompatActivity {

    TextView tvEntradaPelicula;
    TextView tvEntradaFechaHora;
    TextView tvEntradaFila;
    TextView tvEntradaNumeroTickets;
    TextView tvEntradaCine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entrada);

        tvEntradaPelicula = findViewById(R.id.tvEntradaPelicula);
        tvEntradaFechaHora = findViewById(R.id.tvEntradaFechaHora);
        tvEntradaFila = findViewById(R.id.tvEntradaFila);
        tvEntradaNumeroTickets = findViewById(R.id.tvEntradaNumeroTickets);
        tvEntradaCine = findViewById(R.id.tvEntradaCine);

        tvEntradaPelicula.setText("Pelicula: " + getIntent().getStringExtra("pelicula"));
        tvEntradaFechaHora.setText("Fecha y Hora: " + getIntent().getStringExtra("fechahora"));
        tvEntradaFila.setText("Fila: " + String.valueOf(getIntent().getIntExtra("fila", -1)));
        tvEntradaNumeroTickets.setText("Numero de Tickets: " + String.valueOf(getIntent().getIntExtra("numerotickets", -1)));
        tvEntradaCine.setText("Cine: " + getIntent().getStringExtra("cine"));

    }
}